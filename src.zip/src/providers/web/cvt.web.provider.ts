import { CvtNonNotice, CvtNonNoticeSub } from './../entity/cvt.entity.provider';
import { FixedAsset } from './../entity/entity.provider';
import { WebService } from './../service/web.service';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';

@Injectable()
export class CvtWebProvider{
    private Local_URL="";
    constructor(public http: Http,
               private webService:WebService,) {
       this.Local_URL=webService.getURL()+"convert/";
    }
  //从服务器根据员工编号得到资产，，，领用人的
  getAllCvtAsset(noticeId:string,workInOrg:string){
    let params= "?noticeId="+noticeId+"&workInOrg="+workInOrg;
    return new Promise<Array<FixedAsset>>((resolve,reject)=>{
      this.http.get(this.Local_URL+'noninstall/notice/getAllCvtAsset'+params)
      .map(res=>res.json())
      .subscribe((data)=>{
        resolve(data);
      },err=>{
        reject(err);
      })
    })
  }

  /**
   * 获取通知单内容
   * @param recipient 
   * @param orgId 
   */
  getCvtNoticeByRecipientAndOrg(recipient:string,orgId:string){
    let params= "?recipient="+recipient+"&orgId="+orgId;
    return new Promise<CvtNonNotice>((resolve,reject)=>{
      this.http.get(this.Local_URL+'noninstall/notice/getCvtNonNotice'+params)
      .map(res=>res.json())
      .subscribe((data)=>{  
        resolve(data);
      },err=>{
        reject(err);
      })
    })
  }
  getCvtNonNoticeSub(noticeId:string){
    let params= "?noticeId="+noticeId;
    return new Promise<Array<CvtNonNoticeSub>>((resolve,reject)=>{
      this.http.get(this.Local_URL+'noninstall/notice/getCvtNonNoticeSub'+params)
      .map(res=>res.json())
      .subscribe((data)=>{
        resolve(data);
      },err=>{
        reject(err);
      })
    })
  }

  getCvtAssetByAssetName(assetName:string,purchasingId:string,orgId:string){
    let params= "?assetName="+assetName+"&purchasingId="+purchasingId+"&orgId="+orgId;
    return new Promise<Array<FixedAsset>>((resolve,reject)=>{
      this.http.get(this.Local_URL+'noninstall/notice/getCvtAssetByAssetName'+params)
      .map(res=>res.json())
      .subscribe((data)=>{
        resolve(data);
      },err=>{
        reject(err);
      })
    })
  }

  updateStateToCvtNotice(state:string,noticeId:string){
    let params= "?state="+state+"&noticeId="+noticeId;
    return new Promise<string>((resolve,reject)=>{
      this.http.get(this.Local_URL+'noninstall/notice/updateStateToCvtNotice'+params)
      .map(res=>res.json())
      .subscribe((data)=>{
        resolve(data);
      },err=>{
        reject(err);
      })
    })
  }

   


  ///////////////////////////////

  //根据二维码在资产台账中查找数据
  getAssetFromServerFixedByCode(code:string){
    let params= "?code="+code;
    return new Promise<FixedAsset>((resolve,reject)=>{
      this.http.get(this.Local_URL+'getAssetFromServerFixedByCode'+params)
      .map(res=>res.json())
      .subscribe((data)=>{
        resolve(data);
      },err=>{
        reject(err);
      })
    })

  }
//根据资产ID二维码在资产台账中查找数据
  getAssetFromServerFixedByIdAndCode(assetCode:string,twoDimensionCode:string){
    let params= "?assetCode="+assetCode+"twoDimensionCode="+twoDimensionCode;
    return new Promise<FixedAsset>((resolve,reject)=>{
      this.http.get(this.Local_URL+'getAssetFromServerFixedByIdAndCode'+params)
      .map(res=>res.json())
      .subscribe((data)=>{
        resolve(data);
      },err=>{
        reject(err);
      })
    })
  }

 



  
}