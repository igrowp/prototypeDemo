import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { GrantingBindPage } from './granting-bind';

@NgModule({
  declarations: [
    GrantingBindPage,
  ],
  imports: [
    IonicPageModule.forChild(GrantingBindPage),
  ],
})
export class GrantingBindPageModule {}
