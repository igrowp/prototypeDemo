import { Component } from '@angular/core';

@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {

  tab1Root = "HomePage";
  // tab2Root = "InventoryPage";
  // tab3Root = "MinePage";

  constructor() {

  }
}
